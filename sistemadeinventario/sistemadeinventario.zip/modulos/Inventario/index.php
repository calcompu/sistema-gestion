<?php
require_once __DIR__ . '/../../config.php';
// requireLogin(); // Asegura que el usuario esté logueado
requirePermission('inventario_productos', 'view_list');

$pageTitle = "Listado de Productos";
require_once __DIR__ . '/../../includes/header.php';
require_once __DIR__ . '/../../includes/functions.php'; // Para formatCurrency y showAlert

// Configuración de paginación
$productosPorPagina = 10;
$paginaActual = isset($_GET['pagina']) ? (int)$_GET['pagina'] : 1;
if ($paginaActual < 1) $paginaActual = 1;
$offset = ($paginaActual - 1) * $productosPorPagina;

// Filtros y búsqueda
$busqueda = isset($_GET['busqueda']) ? sanitizeInput($_GET['busqueda']) : '';
$filtroCategoria = isset($_GET['categoria_id']) ? (int)$_GET['categoria_id'] : '';
$filtroLugar = isset($_GET['lugar_id']) ? (int)$_GET['lugar_id'] : '';
$filtroStock = isset($_GET['stock']) ? sanitizeInput($_GET['stock']) : ''; // 'disponible', 'bajo', 'sin_stock'

$whereClauses = ["p.activo = 1"];
$params = [];

if (!empty($busqueda)) {
    $whereClauses[] = "(p.nombre LIKE ? OR p.codigo LIKE ? OR p.descripcion LIKE ?)";
    $params[] = "%{$busqueda}%";
    $params[] = "%{$busqueda}%";
    $params[] = "%{$busqueda}%";
}
if (!empty($filtroCategoria)) {
    $whereClauses[] = "p.categoria_id = ?";
    $params[] = $filtroCategoria;
}
if (!empty($filtroLugar)) {
    $whereClauses[] = "p.lugar_id = ?";
    $params[] = $filtroLugar;
}
if ($filtroStock === 'disponible') {
    $whereClauses[] = "p.stock > p.stock_minimo";
} elseif ($filtroStock === 'bajo') {
    $whereClauses[] = "p.stock <= p.stock_minimo AND p.stock > 0";
} elseif ($filtroStock === 'sin_stock') {
    $whereClauses[] = "p.stock <= 0";
}

$whereSql = "WHERE " . implode(" AND ", $whereClauses);

// Obtener total de productos para paginación
$stmtTotal = $pdo->prepare("SELECT COUNT(p.id) FROM productos p $whereSql");
$stmtTotal->execute($params);
$totalProductos = $stmtTotal->fetchColumn();
$totalPaginas = ceil($totalProductos / $productosPorPagina);

// Obtener productos para la página actual
$sql = "SELECT p.*, c.nombre as categoria_nombre, l.nombre as lugar_nombre 
        FROM productos p 
        LEFT JOIN categorias c ON p.categoria_id = c.id 
        LEFT JOIN lugares l ON p.lugar_id = l.id 
        $whereSql 
        ORDER BY p.nombre ASC 
        LIMIT ? OFFSET ?";
$paramsPaged = array_merge($params, [$productosPorPagina, $offset]);
$stmt = $pdo->prepare($sql);
$stmt->execute($paramsPaged);
$productos = $stmt->fetchAll();

// Obtener categorías y lugares para los filtros
$categorias = $pdo->query("SELECT id, nombre FROM categorias ORDER BY nombre ASC")->fetchAll();
$lugares = $pdo->query("SELECT id, nombre FROM lugares ORDER BY nombre ASC")->fetchAll();

?>
<main class="main-content">
    <div class="container-fluid">
        <div class="d-flex justify-content-between align-items-center mb-4">
            <h1 class="h3 mb-0 text-gray-800">Productos en Inventario</h1>
            <div>
                <?php if (hasPermission('inventario_productos', 'create')): ?>
                <a href="producto_form.php" class="btn btn-primary me-2">
                    <i class="bi bi-plus-circle-fill me-1"></i> Nuevo Producto
                </a>
                <?php endif; ?>
                <?php if (hasPermission('inventario_productos', 'export')): ?>
                <a href="exportar_excel.php" class="btn btn-success">
                    <i class="bi bi-file-earmark-excel-fill me-1"></i> Exportar a Excel
                </a>
                <?php endif; ?>
                <!-- Podríamos añadir un enlace a productos inactivos si es necesario -->
            </div>
        </div>

        <?php 
        if (isset($_GET['status'])) {
            if ($_GET['status'] == 'success_create') showAlert('Producto creado exitosamente.', 'success');
            if ($_GET['status'] == 'success_update') showAlert('Producto actualizado exitosamente.', 'success');
            if ($_GET['status'] == 'success_delete') showAlert('Producto eliminado exitosamente.', 'success');
            if ($_GET['status'] == 'error') showAlert('Ocurrió un error.', 'danger');
        }
        ?>

        <div class="card shadow mb-4">
            <div class="card-header py-3">
                <h6 class="m-0 font-weight-bold text-primary">Filtros y Búsqueda</h6>
            </div>
            <div class="card-body">
                <form method="GET" action="index.php" class="row g-3 align-items-end">
                    <div class="col-md-4">
                        <label for="busqueda" class="form-label">Buscar Producto</label>
                        <input type="text" class="form-control" id="busqueda" name="busqueda" value="<?= htmlspecialchars($busqueda) ?>" placeholder="Nombre, código, descripción...">
                    </div>
                    <div class="col-md-2">
                        <label for="categoria_id" class="form-label">Categoría</label>
                        <select class="form-select" id="categoria_id" name="categoria_id">
                            <option value="">Todas</option>
                            <?php foreach ($categorias as $cat): ?>
                                <option value="<?= $cat['id'] ?>" <?= $filtroCategoria == $cat['id'] ? 'selected' : '' ?>><?= htmlspecialchars($cat['nombre']) ?></option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                    <div class="col-md-2">
                        <label for="lugar_id" class="form-label">Lugar</label>
                        <select class="form-select" id="lugar_id" name="lugar_id">
                            <option value="">Todos</option>
                            <?php foreach ($lugares as $lug): ?>
                                <option value="<?= $lug['id'] ?>" <?= $filtroLugar == $lug['id'] ? 'selected' : '' ?>><?= htmlspecialchars($lug['nombre']) ?></option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                    <div class="col-md-2">
                        <label for="stock" class="form-label">Estado de Stock</label>
                        <select class="form-select" id="stock" name="stock">
                            <option value="">Todos</option>
                            <option value="disponible" <?= $filtroStock == 'disponible' ? 'selected' : '' ?>>Disponible</option>
                            <option value="bajo" <?= $filtroStock == 'bajo' ? 'selected' : '' ?>>Stock Bajo</option>
                            <option value="sin_stock" <?= $filtroStock == 'sin_stock' ? 'selected' : '' ?>>Sin Stock</option>
                        </select>
                    </div>
                    <div class="col-md-2 d-flex align-items-end">
                        <button type="submit" class="btn btn-info me-2 w-100"><i class="bi bi-search"></i> Filtrar</button>
                        <a href="index.php" class="btn btn-outline-secondary"><i class="bi bi-x"></i></a>
                    </div>
                </form>
            </div>
        </div>

        <div class="card shadow mb-4">
            <div class="card-header py-3">
                <h6 class="m-0 font-weight-bold text-primary">Listado de Productos</h6>
            </div>
            <div class="card-body">
                <div class="table-responsive">
                    <table class="table table-bordered table-hover" id="dataTableProductos" width="100%" cellspacing="0">
                        <thead class="table-dark">
                            <tr>
                                <th>Código</th>
                                <th>Imagen</th>
                                <th>Nombre</th>
                                <th>Categoría</th>
                                <th>Lugar</th>
                                <th class="text-end">Stock</th>
                                <th class="text-end">Stock Mín.</th>
                                <th class="text-end">Precio Compra</th>
                                <th class="text-end">Precio Venta</th>
                                <th class="text-center">Estado</th>
                                <th class="text-center">Acciones</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php if (empty($productos)): ?>
                                <tr>
                                    <td colspan="11" class="text-center">No se encontraron productos con los filtros aplicados.</td>
                                </tr>
                            <?php else: ?>
                                <?php foreach ($productos as $producto): ?>
                                    <tr>
                                        <td><?= htmlspecialchars($producto['codigo']) ?></td>
                                        <td>
                                            <?php 
                                            $imgPath = '../../assets/uploads/productos/' . ($producto['imagen'] ?? 'default.png');
                                            if (!file_exists(__DIR__ . '/../../' . $imgPath)) { // Doble check para la ruta desde el script
                                                $imgPath = '../../assets/img/default_product.png'; // Un default general
                                            }
                                            ?>
                                            <img src="<?= APP_URL ?>/assets/uploads/productos/<?= htmlspecialchars($producto['imagen'] ?? 'default.png') ?>" 
                                                 alt="<?= htmlspecialchars($producto['nombre']) ?>" 
                                                 style="width: 50px; height: 50px; object-fit: cover; cursor: pointer;" 
                                                 onerror="this.onerror=null; this.src='<?= APP_URL ?>/assets/img/default_product.png';" 
                                                 data-bs-toggle="modal" data-bs-target="#imageModal<?= $producto['id'] ?>">
                                        </td>
                                        <td>
                                            <?php if (hasPermission('inventario_productos', 'view_detail')): ?>
                                            <a href="producto_detalle.php?id=<?= $producto['id'] ?>">
                                                <?= htmlspecialchars($producto['nombre']) ?>
                                            </a>
                                            <?php else: ?>
                                                <?= htmlspecialchars($producto['nombre']) ?>
                                            <?php endif; ?>
                                        </td>
                                        <td><?= htmlspecialchars($producto['categoria_nombre'] ?? 'N/A') ?></td>
                                        <td><?= htmlspecialchars($producto['lugar_nombre'] ?? 'N/A') ?></td>
                                        <td class="text-end"><?= htmlspecialchars($producto['stock']) ?></td>
                                        <td class="text-end"><?= htmlspecialchars($producto['stock_minimo']) ?></td>
                                        <td class="text-end"><?= formatCurrency($producto['precio_compra']) ?></td>
                                        <td class="text-end"><?= formatCurrency($producto['precio_venta']) ?></td>
                                        <td class="text-center">
                                            <?php 
                                            if ($producto['stock'] <= 0) {
                                                echo '<span class="badge bg-danger">Sin Stock</span>';
                                            } elseif ($producto['stock'] <= $producto['stock_minimo']) {
                                                echo '<span class="badge bg-warning text-dark">Stock Bajo</span>';
                                            } else {
                                                echo '<span class="badge bg-success">Disponible</span>';
                                            }
                                            ?>
                                        </td>
                                        <td class="text-center actions-btn-group">
                                            <?php if (hasPermission('inventario_productos', 'view_detail')): ?>
                                            <a href="producto_detalle.php?id=<?= $producto['id'] ?>" class="btn btn-sm btn-info" title="Ver Detalles"><i class="bi bi-eye-fill"></i></a>
                                            <?php endif; ?>
                                            <?php if (hasPermission('inventario_productos', 'edit')): ?>
                                            <a href="producto_form.php?id=<?= $producto['id'] ?>" class="btn btn-sm btn-warning" title="Editar"><i class="bi bi-pencil-fill"></i></a>
                                            <?php endif; ?>
                                            <?php if (hasPermission('inventario_productos', 'delete')): ?>
                                            <form action="producto_acciones.php" method="POST" class="d-inline" onsubmit="return confirm('¿Está seguro de que desea eliminar este producto? Esta acción no se puede deshacer.');">
                                                <input type="hidden" name="accion" value="eliminar_permanente">
                                                <input type="hidden" name="producto_id" value="<?= $producto['id'] ?>">
                                                <input type="hidden" name="csrf_token" value="<?= $_SESSION['csrf_token'] ?>">
                                                <button type="submit" class="btn btn-sm btn-danger" title="Eliminar Permanentemente"><i class="bi bi-trash-fill"></i></button>
                                            </form>
                                            <?php endif; ?>
                                        </td>
                                    </tr>
                                    <!-- Modal para imagen -->
                                    <div class="modal fade" id="imageModal<?= $producto['id'] ?>" tabindex="-1" aria-labelledby="imageModalLabel<?= $producto['id'] ?>" aria-hidden="true">
                                        <div class="modal-dialog modal-sm">
                                            <div class="modal-content">
                                                <div class="modal-header">
                                                    <h5 class="modal-title" id="imageModalLabel<?= $producto['id'] ?>"><?= htmlspecialchars($producto['nombre']) ?></h5>
                                                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                                                </div>
                                                <div class="modal-body text-center">
                                                    <img src="<?= APP_URL ?>/assets/uploads/productos/<?= htmlspecialchars($producto['imagen'] ?? 'default.png') ?>" 
                                                         onerror="this.onerror=null; this.src='<?= APP_URL ?>/assets/img/default_product.png';" 
                                                         class="img-fluid rounded" alt="<?= htmlspecialchars($producto['nombre']) ?>">
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                <?php endforeach; ?>
                            <?php endif; ?>
                        </tbody>
                    </table>
                </div>

                <!-- Paginación -->
                <?php if ($totalPaginas > 1): ?>
                <nav aria-label="Paginación de productos">
                    <ul class="pagination justify-content-center mt-4">
                        <?php 
                        $queryParams = $_GET;
                        unset($queryParams['pagina']); // remover pagina actual para no duplicar
                        $queryString = http_build_query($queryParams);
                        ?>
                        <li class="page-item <?= ($paginaActual <= 1) ? 'disabled' : '' ?>">
                            <a class="page-link" href="?pagina=<?= $paginaActual - 1 ?>&<?= $queryString ?>">Anterior</a>
                        </li>
                        <?php for ($i = 1; $i <= $totalPaginas; $i++): ?>
                            <li class="page-item <?= ($i == $paginaActual) ? 'active' : '' ?>">
                                <a class="page-link" href="?pagina=<?= $i ?>&<?= $queryString ?>"><?= $i ?></a>
                            </li>
                        <?php endfor; ?>
                        <li class="page-item <?= ($paginaActual >= $totalPaginas) ? 'disabled' : '' ?>">
                            <a class="page-link" href="?pagina=<?= $paginaActual + 1 ?>&<?= $queryString ?>">Siguiente</a>
                        </li>
                    </ul>
                </nav>
                <?php endif; ?>

            </div>
        </div>
    </div>
</main>

<?php require_once __DIR__ . '/../../includes/footer.php'; ?> 