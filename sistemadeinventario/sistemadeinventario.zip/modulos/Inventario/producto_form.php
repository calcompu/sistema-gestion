<?php
require_once __DIR__ . '/../../config.php';
// requireLogin(); // Eliminado

$editMode = isset($_GET['id']);
$action_permission = $editMode ? 'edit' : 'create';
requirePermission('inventario_productos', $action_permission);

$pageTitle = "Formulario de Producto";
require_once __DIR__ . '/../../includes/header.php';
require_once __DIR__ . '/../../includes/functions.php';

$producto = [
    'id' => '',
    'nombre' => '',
    'codigo' => '',
    'descripcion' => '',
    'categoria_id' => '',
    'lugar_id' => '',
    'stock' => 0,
    'stock_minimo' => 1,
    'precio_compra' => '0.00',
    'precio_venta' => '0.00',
    'imagen' => ''
];

if (isset($_GET['id'])) {
    $editMode = true;
    $producto_id = (int)$_GET['id'];
    $stmt = $pdo->prepare("SELECT * FROM productos WHERE id = ? AND activo = 1");
    $stmt->execute([$producto_id]);
    $producto_data = $stmt->fetch(PDO::FETCH_ASSOC);
    if ($producto_data) {
        $producto = $producto_data;
    } else {
        showAlert("Producto no encontrado o no activo.", "danger");
        // Podrías redirigir o simplemente no poblar el formulario
        $editMode = false; // Salir del modo edición si no se encuentra
    }
    $pageTitle = "Editar Producto: " . htmlspecialchars($producto['nombre'] ?? 'Error al cargar nombre');
} else {
    $pageTitle = "Crear Nuevo Producto";
    // Generar un código de producto único sugerido (ejemplo simple)
    $stmtMaxCod = $pdo->query("SELECT MAX(CAST(SUBSTRING(codigo, 5) AS UNSIGNED)) as max_cod FROM productos WHERE codigo LIKE 'PROD-%'");
    $maxCodNum = $stmtMaxCod->fetchColumn();
    $producto['codigo'] = 'PROD-' . str_pad(($maxCodNum + 1), 4, '0', STR_PAD_LEFT);
}

// Obtener categorías y lugares para los select
$categorias = $pdo->query("SELECT id, nombre FROM categorias WHERE activa = 1 ORDER BY nombre ASC")->fetchAll(PDO::FETCH_ASSOC);
$lugares = $pdo->query("SELECT id, nombre FROM lugares WHERE activo = 1 ORDER BY nombre ASC")->fetchAll(PDO::FETCH_ASSOC);

?>
<main class="main-content">
    <div class="container-fluid">
        <div class="d-flex justify-content-between align-items-center mb-4">
            <h1 class="h3 mb-0 text-gray-800"><?= $pageTitle ?></h1>
            <a href="index.php" class="btn btn-outline-secondary">
                <i class="bi bi-arrow-left me-1"></i> Volver al Listado
            </a>
        </div>

        <?php 
        if (isset($_SESSION['form_error'])) {
            showAlert(htmlspecialchars($_SESSION['form_error']), 'danger');
            unset($_SESSION['form_error']);
        }
        if (isset($_SESSION['form_data'])) { // Repopular en caso de error
            $producto = array_merge($producto, $_SESSION['form_data']);
            unset($_SESSION['form_data']);
        }
        ?>

        <div class="card shadow mb-4">
            <div class="card-body">
                <form action="producto_acciones.php" method="POST" enctype="multipart/form-data" class="needs-validation" novalidate>
                    <input type="hidden" name="accion" value="<?= $editMode ? 'actualizar' : 'crear' ?>">
                    <input type="hidden" name="csrf_token" value="<?= htmlspecialchars($_SESSION['csrf_token']) ?>">
                    <?php if ($editMode): ?>
                        <input type="hidden" name="producto_id" value="<?= htmlspecialchars($producto['id']) ?>">
                    <?php endif; ?>

                    <div class="row">
                        <div class="col-md-8">
                            <div class="row">
                                <div class="col-md-8 mb-3">
                                    <label for="nombre" class="form-label">Nombre del Producto <span class="text-danger">*</span></label>
                                    <input type="text" class="form-control" id="nombre" name="nombre" value="<?= htmlspecialchars($producto['nombre'] ?? '') ?>" required>
                                    <div class="invalid-feedback">Por favor, ingrese el nombre del producto.</div>
                                </div>
                                <div class="col-md-4 mb-3">
                                    <label for="codigo" class="form-label">Código <span class="text-danger">*</span></label>
                                    <input type="text" class="form-control" id="codigo" name="codigo" value="<?= htmlspecialchars($producto['codigo'] ?? '') ?>" required>
                                    <div class="invalid-feedback">Por favor, ingrese un código para el producto.</div>
                                </div>
                            </div>

                            <div class="mb-3">
                                <label for="descripcion" class="form-label">Descripción</label>
                                <textarea class="form-control" id="descripcion" name="descripcion" rows="3"><?= htmlspecialchars($producto['descripcion'] ?? '') ?></textarea>
                            </div>

                            <div class="row">
                                <div class="col-md-6 mb-3">
                                    <label for="categoria_id" class="form-label">Categoría <span class="text-danger">*</span></label>
                                    <select class="form-select" id="categoria_id" name="categoria_id" required>
                                        <option value="">Seleccione una categoría...</option>
                                        <?php foreach ($categorias as $cat): ?>
                                            <option value="<?= $cat['id'] ?>" <?= (($producto['categoria_id'] ?? '') == $cat['id']) ? 'selected' : '' ?>><?= htmlspecialchars($cat['nombre']) ?></option>
                                        <?php endforeach; ?>
                                    </select>
                                    <div class="invalid-feedback">Por favor, seleccione una categoría.</div>
                                </div>
                                <div class="col-md-6 mb-3">
                                    <label for="lugar_id" class="form-label">Lugar/Ubicación</label>
                                    <select class="form-select" id="lugar_id" name="lugar_id">
                                        <option value="">Seleccione un lugar...</option>
                                        <?php foreach ($lugares as $lug): ?>
                                            <option value="<?= $lug['id'] ?>" <?= (($producto['lugar_id'] ?? '') == $lug['id']) ? 'selected' : '' ?>><?= htmlspecialchars($lug['nombre']) ?></option>
                                        <?php endforeach; ?>
                                    </select>
                                </div>
                            </div>

                            <div class="row">
                                <div class="col-md-3 mb-3">
                                    <label for="stock" class="form-label">Stock Actual <span class="text-danger">*</span></label>
                                    <input type="number" class="form-control" id="stock" name="stock" value="<?= htmlspecialchars($producto['stock'] ?? '0') ?>" min="0" required>
                                    <div class="invalid-feedback">Ingrese un stock válido (0 o más).</div>
                                </div>
                                <div class="col-md-3 mb-3">
                                    <label for="stock_minimo" class="form-label">Stock Mínimo <span class="text-danger">*</span></label>
                                    <input type="number" class="form-control" id="stock_minimo" name="stock_minimo" value="<?= htmlspecialchars($producto['stock_minimo'] ?? '1') ?>" min="0" required>
                                     <div class="invalid-feedback">Ingrese un stock mínimo válido.</div>
                                </div>
                                <div class="col-md-3 mb-3">
                                    <label for="precio_compra" class="form-label">Precio Compra</label>
                                    <input type="text" class="form-control" id="precio_compra" name="precio_compra" value="<?= htmlspecialchars($producto['precio_compra'] ?? '0.00') ?>" pattern="^\\d*([.,]\\d{1,2})?$">
                                    <div class="invalid-feedback">Ingrese un precio de compra válido (ej: 123.45).</div>
                                </div>
                                <div class="col-md-3 mb-3">
                                    <label for="precio_venta" class="form-label">Precio Venta <span class="text-danger">*</span></label>
                                    <input type="text" class="form-control" id="precio_venta" name="precio_venta" value="<?= htmlspecialchars($producto['precio_venta'] ?? '0.00') ?>" pattern="^\\d*([.,]\\d{1,2})?$" required>
                                    <div class="invalid-feedback">Ingrese un precio de venta válido (ej: 123.45).</div>
                                </div>
                            </div>
                        </div>

                        <div class="col-md-4">
                            <div class="mb-3">
                                <label for="imagen" class="form-label">Imagen del Producto</label>
                                <input class="form-control form-control-file image-preview" type="file" id="imagen" name="imagen" accept="image/png, image/jpeg, image/gif" data-preview-target="#imagePreview">
                                <small class="form-text text-muted">Formatos permitidos: JPG, PNG, GIF. Tamaño máximo: 2MB.</small>
                            </div>
                            <div id="imagePreview" class="mb-3 text-center">
                                <?php if ($editMode && !empty($producto['imagen'])): ?>
                                    <img src="<?= APP_URL . '/assets/uploads/productos/' . htmlspecialchars($producto['imagen']) ?>" alt="Imagen actual" class="img-fluid rounded" style="max-height: 200px;">
                                <?php else: ?>
                                    <img src="<?= APP_URL ?>/assets/img/default_product_placeholder.png" alt="Placeholder" class="img-fluid rounded" style="max-height: 200px; border: 1px dashed #ccc; padding:10px;">
                                <?php endif; ?>
                            </div>
                            <?php if ($editMode && !empty($producto['imagen'])) : ?>
                                <input type="hidden" name="imagen_actual" value="<?= htmlspecialchars($producto['imagen']) ?>">
                                <div class="form-check mb-3">
                                    <input class="form-check-input" type="checkbox" value="1" id="eliminar_imagen" name="eliminar_imagen">
                                    <label class="form-check-label" for="eliminar_imagen">
                                        Eliminar imagen actual
                                    </label>
                                </div>
                            <?php endif; ?>
                        </div>
                    </div>

                    <hr class="my-4">

                    <div class="d-flex justify-content-end">
                        <a href="index.php" class="btn btn-secondary me-2">Cancelar</a>
                        <button type="submit" class="btn btn-primary">
                            <i class="bi bi-save-fill me-1"></i> <?= $editMode ? 'Actualizar Producto' : 'Guardar Producto' ?>
                        </button>
                    </div>
                </form>
            </div>
        </div>
    </div>
</main>
<?php require_once __DIR__ . '/../../includes/footer.php'; ?> 