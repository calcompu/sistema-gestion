<?php
// Configuración de la base de datos
define('DB_HOST', 'localhost'); // Cambia esto si tu DB está en otro servidor
define('DB_NAME', 'sistemasia_inventpro'); // Nombre de tu base de datos
define('DB_USER', 'sistemasia_inventpro'); // Usuario de tu base de datos
define('DB_PASS', '9QxMIvtb^(-D'); // Contraseña de tu base de datos
define('DB_CHARSET', 'utf8mb4');

// Configuración de la aplicación
define('APP_URL', 'http://localhost/sistemadeinventario'); // URL base de tu aplicación
define('APP_NAME', 'Sistema de Inventario');
define('SESSION_TIMEOUT', 1800); // Tiempo de vida de la sesión en segundos (30 minutos)

// Directorio para backups (aseúrate de que este directorio exista y tenga permisos de escritura)
define('BACKUP_DIR', __DIR__ . '/backups/');

// Definición de Roles del Sistema
define('USER_ROLES', [
    'admin' => 'Administrador',
    'editor' => 'Editor',
    'usuario' => 'Usuario'
]);

// Opciones de PDO
$options = [
    PDO::ATTR_ERRMODE            => PDO::ERRMODE_EXCEPTION,
    PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
    PDO::ATTR_EMULATE_PREPARES   => false,
];

// DSN (Data Source Name)
$dsn = "mysql:host=" . DB_HOST . ";dbname=" . DB_NAME . ";charset=" . DB_CHARSET;

try {
    $pdo = new PDO($dsn, DB_USER, DB_PASS, $options);
} catch (PDOException $e) {
    // En un entorno de producción, no mostrarías detalles del error al usuario.
    // Registrarías el error y mostrarías un mensaje genérico.
    error_log("Error de conexión a la base de datos: " . $e->getMessage());
    // Para desarrollo, puedes mostrar el error:
    // die("Error de conexión a la base de datos: " . $e->getMessage()); 
    // Para producción, un mensaje más amigable:
    die("Lo sentimos, estamos experimentando problemas técnicos. Por favor, inténtelo más tarde.");
}

// Configuración de la zona horaria
date_default_timezone_set('America/Lima'); // Ajusta a tu zona horaria

// Iniciar sesión si no está iniciada (importante para auth.php y otras partes)
if (session_status() == PHP_SESSION_NONE) {
    session_name("InventarioSession"); // Nombre personalizado para la cookie de sesión
    session_set_cookie_params([
        'lifetime' => SESSION_TIMEOUT, // Duración de la cookie de sesión
        'path' => '/', // Disponible en todo el dominio
        'httponly' => true, // Prevenir acceso por JavaScript
        'samesite' => 'Lax' // Protección CSRF
    ]);
    session_start();
}

// Generar token CSRF si no existe
if (empty($_SESSION['csrf_token'])) {
    $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
}

// Autenticación (Adaptado de includes/auth.php)
function requireLogin($redirectUrl = 'index.php') {
    if (!isset($_SESSION['user_id'])) {
        // Guardar la URL a la que se intentaba acceder, para redirigir después del login
        $_SESSION['redirect_url'] = $_SERVER['REQUEST_URI'];
        
        header("Location: " . APP_URL . "/" . $redirectUrl . "?error=not_logged_in");
        exit();
    }
    // Refrescar el tiempo de vida de la sesión en cada página protegida
    if (isset($_SESSION['LAST_ACTIVITY']) && (time() - $_SESSION['LAST_ACTIVITY'] > SESSION_TIMEOUT)) {
        session_unset();     // Eliminar todas las variables de sesión
        session_destroy();   // Destruir la sesión
        header("Location: " . APP_URL . "/" . $redirectUrl . "?error=session_expired");
        exit();
    }
    $_SESSION['LAST_ACTIVITY'] = time(); // Actualizar el último tiempo de actividad
}

// ---- INICIO: Definición de Permisos por Rol ----

// Intentar cargar permisos desde el archivo de configuración generado
$custom_permissions_file = __DIR__ . '/permissions.config.php';
if (file_exists($custom_permissions_file)) {
    require_once $custom_permissions_file; // Esto debería definir la variable $permissions
} else {
    // Si el archivo no existe, usar la configuración de permisos por defecto
    global $permissions;
    $permissions = [
        'admin' => [ 
            'all_modules' => true, 
            'admin_usuarios' => ['manage' => true], 
            'admin_logs' => ['view' => true],
            'admin_roles' => ['manage' => true], 
            'admin_backup' => ['manage' => true],
            'admin_dashboard' => ['view' => true],
            'inventario_productos' => ['manage' => true, 'export' => true],
            'inventario_categorias' => ['manage' => true],
            'inventario_lugares' => ['manage' => true],
        ],
        'editor' => [
            'menu_principal' => ['view' => true],
            'inventario_productos' => ['view_list' => true, 'view_detail' => true, 'create' => true, 'edit' => true, 'delete' => true, 'export' => true],
            'inventario_categorias' => ['view_list' => true, 'view_detail' => false, 'create' => true, 'edit' => true, 'delete' => true, 'toggle_status' => true],
            'inventario_lugares' => ['view_list' => true, 'view_detail' => false, 'create' => true, 'edit' => true, 'delete' => true, 'toggle_status' => true],
            'pedidos' => ['view_list' => true, 'view_detail' => true, 'create' => true, 'edit' => true, 'cancel' => true],
            'clientes' => ['view_list' => true, 'view_detail' => false, 'create' => true, 'edit' => true, 'delete' => true, 'toggle_status' => true],
            'facturacion' => ['view_list' => true, 'view_detail' => true, 'create_from_order' => true, 'void' => true],
        ],
        'usuario' => [
            'menu_principal' => ['view' => true],
        ]
    ];
}
// ---- FIN: Definición de Permisos por Rol ----

// Nueva función para verificar permisos más granulares
function hasPermission($module, $action) {
    global $permissions; // Acceder a la variable global de permisos

    if (!isset($_SESSION['user_rol'])) {
        return false; // No hay rol, no hay permisos
    }
    $userRole = $_SESSION['user_rol'];

    // El permiso 'all_modules' otorga acceso completo
    if (isset($permissions[$userRole]['all_modules']) && $permissions[$userRole]['all_modules'] === true) {
        return true;
    }

    // Verificar si el rol tiene el permiso específico para el módulo y la acción
    if (isset($permissions[$userRole][$module]) && isset($permissions[$userRole][$module][$action]) && $permissions[$userRole][$module][$action] === true) {
        return true;
    }

    // Si la acción solicitada es una acción CRUD común y el rol tiene el permiso 'manage' para ese módulo
    $crudActions = ['view_list', 'view_detail', 'create', 'edit', 'delete', 'toggle_status'];
    if (in_array($action, $crudActions) && isset($permissions[$userRole][$module]['manage']) && $permissions[$userRole][$module]['manage'] === true) {
        return true;
    }
    
    return false;
}

// Nueva función para requerir un permiso específico y redirigir si no se cumple
function requirePermission($module, $action, $redirectUrl = 'menu_principal.php?error=unauthorized_action') {
    requireLogin(); // Asegurar que el usuario está logueado primero
    if (!hasPermission($module, $action)) {
        // Registrar intento de acceso no autorizado
        // Usamos $GLOBALS['pdo'] porque $pdo podría no estar en el scope directo de esta función
        // y $permissions sí está como global.
        if (isset($GLOBALS['pdo']) && function_exists('logSystemEvent')) {
             logSystemEvent(
                $GLOBALS['pdo'],
                'SECURITY',
                'UNAUTHORIZED_ACCESS_ATTEMPT',
                "Intento de acceso no autorizado al módulo '{$module}', acción '{$action}'.",
                'Authorization',
                ['module' => $module, 'action' => $action, 'user_rol' => $_SESSION['user_rol'] ?? 'desconocido']
            );
        }
        setGlobalMessage("Acceso denegado. No tiene permisos para realizar esta acción.", "danger");
        header("Location: " . APP_URL . "/" . $redirectUrl);
        exit();
    }
}

// checkRole y requireRole pueden mantenerse por compatibilidad o para chequeos de rol generales,
// pero es preferible usar hasPermission/requirePermission para control granular.
function checkRole($allowedRoles) {
    if (!isset($_SESSION['user_rol'])) {
        return false;
    }
    $userRole = $_SESSION['user_rol'];

    if (is_array($allowedRoles)) {
        return in_array($userRole, $allowedRoles);
    }
    return $userRole === $allowedRoles;
}

function requireRole($allowedRoles, $redirectUrl = 'menu_principal.php?error=unauthorized_role') {
    requireLogin();
    if (!checkRole($allowedRoles)) {
        if (isset($GLOBALS['pdo']) && function_exists('logSystemEvent')) {
             logSystemEvent(
                $GLOBALS['pdo'],
                'SECURITY',
                'UNAUTHORIZED_ROLE_ACCESS',
                "Intento de acceso con rol no permitido. Roles permitidos: " . (is_array($allowedRoles) ? implode(', ', $allowedRoles) : $allowedRoles),
                'Authorization',
                ['required_roles' => $allowedRoles, 'user_rol' => $_SESSION['user_rol'] ?? 'desconocido']
            );
        }
        setGlobalMessage("Acceso denegado. Su rol no tiene permisos para acceder a esta sección.", "danger");
        header("Location: " . APP_URL . "/" . $redirectUrl);
        exit();
    }
}
?> 