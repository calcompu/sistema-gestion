<?php
require_once 'config.php'; // config.php maneja session_name, session_set_cookie_params y session_start()
// session_start(); // session_start() ya es llamado dentro de config.php si es necesario, o justo después de configuraciones.
require_once 'includes/functions.php'; // Asegurar que logSystemEvent está disponible

$error = '';

if (isset($_SESSION['user_id'])) {
    header('Location: menu_principal.php');
    exit();
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $username = $_POST['username'];
    $password = $_POST['password'];

    if (empty($username) || empty($password)) {
        $error = 'Por favor, ingrese su usuario y contraseña.';
    } else {
        try {
            $stmt = $pdo->prepare("SELECT id, username, password_hash, rol FROM usuarios WHERE username = ? AND activo = 1");
            $stmt->execute([$username]);
            $user = $stmt->fetch();

            if ($user && password_verify($password, $user['password_hash'])) {
                $_SESSION['user_id'] = $user['id'];
                $_SESSION['username'] = $user['username'];
                $_SESSION['user_rol'] = $user['rol']; // Guardamos el rol del usuario
                
                // Log de inicio de sesión exitoso
                logSystemEvent($pdo, 'INFO', 'LOGIN_SUCCESS', "Usuario '{$username}' inició sesión exitosamente.", 'Auth', null, $user['id']);

                // Redirigir a la URL guardada o al menú principal
                $redirectTo = 'menu_principal.php';
                if (isset($_SESSION['redirect_url'])) {
                    $saved_url = $_SESSION['redirect_url'];
                    unset($_SESSION['redirect_url']); // Limpiar para usos futuros
                    // Validación básica para evitar redirecciones abiertas a dominios externos
                    // Asegurarse de que la URL sea relativa al APP_URL o una ruta local absoluta
                    if (strpos($saved_url, '//') === false || strpos($saved_url, APP_URL) === 0) {
                         // Si es una URL relativa dentro del sitio (no empieza con http/https)
                        if (strpos($saved_url, 'http') !== 0) {
                            // Necesitamos asegurar que es relativa a la raíz del sitio, no a APP_URL directamente si APP_URL tiene subdirectorios
                            // $_SERVER['REQUEST_URI'] usualmente es como /sistemadeinventario/modulo/pagina.php
                            // APP_URL es http://localhost/sistemadeinventario
                            // Si $saved_url es /sistemadeinventario/otrapagina.php, está bien.
                            // Si $saved_url es solo modulo/pagina.php, necesitamos que sea relativa a la raíz, no a APP_URL.
                            // Dado que $_SERVER['REQUEST_URI'] ya incluye la base del sitio si está en un subdirectorio, debería estar bien.
                            $redirectTo = $saved_url; // Usar la URL tal cual fue guardada desde REQUEST_URI
                        } elseif (strpos($saved_url, APP_URL) === 0) { // Si es una URL absoluta pero dentro de nuestro sitio
                            $redirectTo = $saved_url;
                        }
                    }
                }
                header("Location: " . $redirectTo);
                exit();
            } else {
                // Log de inicio de sesión fallido
                // Nota: $user['id'] no estará disponible aquí si el usuario no existe.
                // Si el usuario existe pero la contraseña es incorrecta, podríamos loguear $user['id'].
                // Por simplicidad, no pasaremos user_id para fallos generales.
                logSystemEvent($pdo, 'WARNING', 'LOGIN_FAILURE', "Intento de inicio de sesión fallido para el usuario '{$username}'.", 'Auth', ['username_attempted' => $username]);
                $error = 'Usuario o contraseña incorrectos.';
            }
        } catch (PDOException $e) {
            logSystemEvent($pdo, 'ERROR', 'LOGIN_EXCEPTION', "Excepción de BD durante el intento de login para '{$username}'. Error: " . $e->getMessage(), 'Auth', ['username_attempted' => $username]);
            $error = "Error de conexión: " . $e->getMessage();
        }
    }
}
?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login - Sistema de Inventario</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons/font/bootstrap-icons.css" rel="stylesheet">
    <link rel="stylesheet" href="assets/css/style.css"> <!-- Enlace a tu CSS personalizado si existe -->
    <style>
        body {
            display: flex;
            align-items: center;
            justify-content: center;
            min-height: 100vh;
            background-color: #f8f9fa;
        }
        .login-card {
            width: 100%;
            max-width: 400px;
        }
    </style>
</head>
<body>
    <div class="card login-card shadow">
        <div class="card-body p-4">
            <div class="text-center mb-4">
                <!-- <img src="assets/img/logo.png" alt="Logo" style="width: 100px; height: auto;"> -->
                <h2 class="mt-2">Sistema de Inventario</h2>
                <p class="text-muted">Iniciar Sesión</p>
            </div>

            <?php if (!empty($error)): ?>
                <div class="alert alert-danger alert-dismissible fade show" role="alert">
                    <i class="bi bi-exclamation-triangle-fill me-2"></i>
                    <?= htmlspecialchars($error) ?>
                    <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                </div>
            <?php endif; ?>

            <form method="POST" action="index.php" class="needs-validation" novalidate>
                <div class="mb-3">
                    <label for="username" class="form-label">Usuario</label>
                    <div class="input-group">
                        <span class="input-group-text"><i class="bi bi-person-fill"></i></span>
                        <input type="text" class="form-control" id="username" name="username" required 
                               value="<?= isset($_POST['username']) ? htmlspecialchars($_POST['username']) : '' ?>">
                        <div class="invalid-feedback">Por favor, ingrese su usuario.</div>
                    </div>
                </div>
                <div class="mb-3">
                    <label for="password" class="form-label">Contraseña</label>
                    <div class="input-group">
                        <span class="input-group-text"><i class="bi bi-lock-fill"></i></span>
                        <input type="password" class="form-control" id="password" name="password" required>
                        <div class="invalid-feedback">Por favor, ingrese su contraseña.</div>
                    </div>
                </div>
                <!-- <div class="mb-3 form-check">
                    <input type="checkbox" class="form-check-input" id="rememberMe">
                    <label class="form-check-label" for="rememberMe">Recordarme</label>
                </div> -->
                <div class="d-grid">
                    <button type="submit" class="btn btn-primary btn-lg">
                        <i class="bi bi-box-arrow-in-right"></i> Ingresar
                    </button>
                </div>
            </form>
            <!-- <div class="text-center mt-3">
                <a href="#" class="text-decoration-none">¿Olvidó su contraseña?</a>
            </div> -->
        </div>
        <div class="card-footer text-center py-3">
            <small class="text-muted">&copy; <?= date("Y") ?> Mi Empresa. Todos los derechos reservados.</small>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    <script>
        // Validación Bootstrap
        (function () {
            'use strict'
            var forms = document.querySelectorAll('.needs-validation')
            Array.prototype.slice.call(forms)
                .forEach(function (form) {
                    form.addEventListener('submit', function (event) {
                        if (!form.checkValidity()) {
                            event.preventDefault()
                            event.stopPropagation()
                        }
                        form.classList.add('was-validated')
                    }, false)
                })
        })()
    </script>
</body>
</html>